package com.lrm.service;

import com.lrm.po.User;

/**
 *  Created by xhd on 2021/06/15.
 */
public interface UserService {

    User checkUser(String username, String password);
}
